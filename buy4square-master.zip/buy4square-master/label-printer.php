<?php
$label_url = $_GET['label_url'];
?>
<!DOCTYPE html>
<html>
<body>
<img src="<?php echo $label_url ?>" alt="shipping label" style="width:345px; height:517.5px;">
</body>
</html>
